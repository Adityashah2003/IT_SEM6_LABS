function changeColor(color) {
	document.bgColor = color;
}
